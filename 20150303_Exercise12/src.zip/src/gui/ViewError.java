package gui;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ViewError extends JFrame {

	private JOptionPane error;
	
	
}
