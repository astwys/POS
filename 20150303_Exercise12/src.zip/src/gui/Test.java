package gui;

import javax.swing.JFrame;

public class Test {
	public static void main(String[] args) {
		View frame=null;
		frame=new View();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}